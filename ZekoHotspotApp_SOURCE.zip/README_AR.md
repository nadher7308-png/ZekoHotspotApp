# Zeko Hotspot

تطبيق Android عادي يفتح صفحة MikroTik Hotspot مباشرة من:

`http://g.na/login`

التطبيق لا يعتمد على Chrome WebAPK، ولا يحتاج إلى الدومين القديم `google.1sh.org`.

## بناء APK

1. افتح المشروع في Android Studio.
2. انتظر مزامنة Gradle.
3. اختر **Build > Build APK(s)**.
4. ملف الـAPK الناتج يكون داخل:
   `app/build/outputs/apk/debug/app-debug.apk`

## البناء عبر GitHub Actions

يوجد Workflow جاهز باسم **Build Zeko Hotspot APK**. بعد رفع المشروع إلى GitHub:

Actions → Build Zeko Hotspot APK → Run workflow

وسيتم إنشاء `app-debug.apk` كـ Artifact.

## ملاحظة

يجب أن يكون الهاتف متصلًا بشبكة MikroTik التي توفر اسم DNS `g.na` وتوجهه إلى صفحة الـHotspot.
